import React from "react";
import ReactDOM from "react-dom";

import Navigation from "./components/Navigation";
import Map from "./components/Map";
import RecentAlerts from "./components/RecentAlerts";
import RecentEvents from "./components/RecentEvents";
import CreateNewMember from "./components/CreateNewMember";
import CreateEmergencyContact from "./components/CreateEmergencyContact";
import Guides from "./components/Guides";
import Menu from "./components/Menu/Menu";

import "./styles.css";

function App() {
  return (
    <div className="App">
      <Navigation />
      <Map />
      <RecentAlerts />
      <RecentEvents />
      <CreateNewMember />
      <CreateEmergencyContact />
      <Menu />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
