import React from "react";

const Map = () => (
  <div id="map">
    <div id="location-bar">
      <p>Location</p>
      <div>
        <button>Btn1</button>
        <button>Search</button>
      </div>
    </div>
    <div id="map-content">MAP</div>
  </div>
);

export default Map;
