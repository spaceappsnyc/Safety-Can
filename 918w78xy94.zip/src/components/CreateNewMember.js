import React, { Component } from "react";

class CreateNewMember extends Component {
  constructor(props) {
    super(props);

    this.createNewMember = this.createNewMember.bind(this);
  }

  createNewMember(name, phoneNumber, email, age, conditions) {
    console.log(name);
    console.log(phoneNumber);
  }

  render() {
    return (
      <div id="create-new-member">
        <form>
          <legend>Create New Member</legend>
          <div>
            <label>Name</label>
            <input id="name-member" type="text" />
          </div>
          <div>
            <label>Phone Number</label>
            <input id="phone-number-member" type="text" />
          </div>
          <div>
            <label>Email</label>
            <input id="email-member" type="email" />
          </div>
          <div>
            <label>Age</label>
            <input id="age" type="number" />
          </div>
          <div>
            <label>Has Special Needs?</label>
            <input type="radio" name="special-needs" value="yes" />Yes
            <input type="radio" name="special-needs" value="no" />No
          </div>
          <div>
            <label>Conditions</label>
            <input id="conditions" type="text" />
          </div>
          <div>
            <input
              id="submit-btn-1"
              onclick={this.createNewMember(
                "Jeff",
                "6328484834",
                "gege@gmail.com",
                64,
                "BAD"
              )}
              type="button"
              value="Submit"
            />
          </div>
        </form>
      </div>
    );
  }
}

export default CreateNewMember;
