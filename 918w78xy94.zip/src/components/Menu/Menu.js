import React, { Component } from "react";

import "./Menu.css";

class Menu extends Component {
  state = {
    showMenu: false
  };

  handleMenuToggle = () => {
    this.setState(prevState => {
      return { showMenu: !prevState.showMenu };
    });
  };

  renderMenu() {
    return;
    {
      this.state.showMenu ? (
        <React.Fragment>
          <div id="panel">Hello</div>
          <div id="shade" onClick={this.handleMenuToggle} />
        </React.Fragment>
      ) : null;
    }
  }

  render() {
    return (
      <div>
        <a onClick={this.handleMenuToggle}>
          <i className="fas fa-bars" />
        </a>
        {this.renderMenu()}
      </div>
    );
  }
}

export default Menu;
