import React, { Component } from "react";

class CreateEmergencyContact extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div id="create-emergency-contact">
        <form>
          <legend>Create Emergency Contact</legend>
          <div>
            <label for="">Name</label>
            <input id="name-contact" type="text" />
          </div>
          <div>
            <label for="">Phone Number</label>
            <input id="phone-number-contact" type="text" />
          </div>
          <div>
            <label for="">Email</label>
            <input id="email-contact" type="text" />
          </div>
          <div>
            <input id="submit-btn-2" type="button" value="Submit" />
          </div>
        </form>
      </div>
    );
  }
}

export default CreateEmergencyContact;
