import React from "react";
import { Glyphicon } from "react-bootstrap";

import "./Navigation.css";

const Navigation = () => {
  return (
    <div id="navbar">
      <a href="#">
        <i className="fas fa-bars" />
      </a>
      <a id="brand" href="#">
        SafetyCan
      </a>
      <a href="#">
        <i className="fas fa-user" />
      </a>
    </div>
  );
};

export default Navigation;
